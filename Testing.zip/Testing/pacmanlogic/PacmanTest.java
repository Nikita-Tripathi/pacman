import static org.junit.Assert.*;
import org.junit.Test;
import pacmanlogic.*;

public class PacmanTest{
    @Test
    public void No_of_Lives_Initially(){
        Pacman p = new Pacman();
        assertEquals("The number of lives initially",3,p.getLives());
    }

}