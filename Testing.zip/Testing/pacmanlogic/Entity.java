package pacmanlogic;

public abstract class Entity{
    public abstract int[] move(String input);

    public abstract void setPosition(int[] position);

    public abstract int[] getPosition();
    
}
