import static org.junit.Assert.*;
import org.junit.Test;
import pacmanlogic.*;
import java.util.Arrays;

public class GhostTest{
    @Test
    public void value_of_powerstatus_is_boolean(){
        Ghost g = new Ghost();
        g.setPowerStatus(true);
        assertEquals("The powerstatus getters and setters must be boolean",true,(g.getPowerStatus()));
    }
    
}